## Module <pos_dashboard>

#### 09.10.2021
#### Version 16.0.1.0.0
##### ADD
-Initial Commit for pos_dashboard

#### 15.05.2023
#### Version 16.0.2.0.1
##### FIX
-Error of increasing the font in the entire database removed